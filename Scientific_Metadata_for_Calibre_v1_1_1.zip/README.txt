Scientific Metadata for Calibre — version 1.1.0

Metadata source plugin for calibre 9.18 and later.

SOURCES
- arXiv: official arXiv Atom API.
- ACL Anthology: official MODS XML metadata and article landing page.

INSTALLATION
1. In calibre, open Preferences > Plugins > Load plugin from file.
2. Select Scientific_Metadata_for_Calibre_v1_1_0.zip.
3. Confirm the security prompt.
4. In Preferences > Metadata download, ensure the source is enabled.

USE
Use Download metadata on a record whose title contains an arXiv ID (for example,
1911.02116v2) or an ACL Anthology ID (for example, 2021.acl-long.243).

ACL ANTHOLOGY
The plugin retrieves MODS XML from https://aclanthology.org/{id}.xml and the
landing page for the abstract. It supports modern IDs such as 2021.acl-long.243
and legacy IDs such as E91-1001.

PRESERVATION
The plugin does not set or replace tags. Existing user-defined tags/collections
are preserved. The PDF file itself is not modified.

LIMITATIONS
- Identifiers must be present in the Calibre title or identifiers.
- Abstract retrieval depends on the ACL landing page being available.
- This build has been statically checked and tested against the published ACL
  metadata structure for 2021.acl-long.243; live installation in calibre 9.18
  remains to be confirmed by the user.

ACL Anthology filename handling: optional trailing version suffixes such as v2 are ignored when resolving the canonical Anthology identifier. The original PDF filename is not changed.
