# -*- coding: utf-8 -*-
"""ArXiv metadata source for calibre.

Looks up an arXiv identifier in the filename-derived title or identifiers and
returns authoritative bibliographic metadata from the official arXiv Atom API.
"""

import re
import time
import threading
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from html import unescape
from urllib.parse import quote

from calibre.ebooks.metadata.book.base import Metadata
from calibre.ebooks.metadata.sources.base import Source
from calibre.utils.date import parse_date


ATOM_NS = '{http://www.w3.org/2005/Atom}'
ARXIV_NS = '{http://arxiv.org/schemas/atom}'
MODS_NS = '{http://www.loc.gov/mods/v3}'
_ACL_NEW_ID = re.compile(r'(?<![A-Za-z0-9])(\d{4}\.[a-z0-9]+-[a-z0-9]+\.\d+)(?:v\d+)?(?![A-Za-z0-9])', re.I)
_ACL_OLD_ID = re.compile(r'(?<![A-Za-z0-9])([A-Z]\d{2}-\d{3,4})(?:v\d+)?(?![A-Za-z0-9])', re.I)

# New-style IDs: 1911.02116, 2402.00786v5
_NEW_ID = re.compile(r'(?<![0-9])(\d{4}\.\d{4,5})(v\d+)?(?![0-9])', re.I)
# Legacy IDs: hep-th/9901001, math.GT/0309136v2
_OLD_ID = re.compile(r'(?<![A-Za-z0-9])([a-z][a-z.-]+/\d{7})(v\d+)?(?![0-9])', re.I)

# arXiv's API terms require at most one request every three seconds and one
# connection at a time. Calibre can ask several workers for metadata together,
# so serialize requests within this Calibre process.
_API_LOCK = threading.Lock()
_LAST_API_REQUEST = 0.0
_API_MIN_INTERVAL = 3.1


def _clean_text(value):
    return ' '.join((value or '').split())


def _extract_arxiv_id(title=None, identifiers=None):
    identifiers = identifiers or {}
    # Prefer an explicit arXiv identifier supplied by calibre or another source.
    for key, value in identifiers.items():
        if str(key).lower() in ('arxiv', 'arxiv.org') and value:
            candidate = str(value).strip()
            candidate = re.sub(r'^https?://(?:www\.)?arxiv\.org/(?:abs|pdf)/', '', candidate, flags=re.I)
            candidate = candidate.removesuffix('.pdf')
            match = _NEW_ID.search(candidate) or _OLD_ID.search(candidate)
            if match:
                return match.group(0)

    text = title or ''
    match = _NEW_ID.search(text) or _OLD_ID.search(text)
    return match.group(0) if match else None


def _parse_entry(xml_data, requested_id):
    root = ET.fromstring(xml_data)
    entry = root.find(ATOM_NS + 'entry')
    if entry is None:
        return None

    title = _clean_text(entry.findtext(ATOM_NS + 'title'))
    abstract = _clean_text(entry.findtext(ATOM_NS + 'summary'))
    authors = [_clean_text(node.findtext(ATOM_NS + 'name'))
               for node in entry.findall(ATOM_NS + 'author')]
    authors = [name for name in authors if name]

    published = _clean_text(entry.findtext(ATOM_NS + 'published'))
    updated = _clean_text(entry.findtext(ATOM_NS + 'updated'))
    entry_id = _clean_text(entry.findtext(ATOM_NS + 'id'))

    # Keep the requested version in the stored identifier. The API returns the
    # requested version when vN is supplied in id_list.
    arxiv_id = requested_id
    if entry_id:
        match = _NEW_ID.search(entry_id) or _OLD_ID.search(entry_id)
        if match:
            returned_id = match.group(0)
            # API entry id includes the version when a version was requested.
            if re.search(r'v\d+$', requested_id, re.I):
                arxiv_id = returned_id
            else:
                arxiv_id = returned_id

    if not title or not authors:
        return None

    categories = [node.attrib.get('term', '').strip()
                  for node in entry.findall(ATOM_NS + 'category')]
    categories = [x for x in categories if x]
    doi = _clean_text(entry.findtext(ARXIV_NS + 'doi'))

    return {
        'title': title,
        'authors': authors,
        'abstract': abstract,
        'published': published,
        'updated': updated,
        'arxiv_id': arxiv_id,
        'doi': doi,
        'categories': categories,
    }


class _ACLAbstractParser(HTMLParser):
    """Extract the Abstract section from an ACL Anthology landing page."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_h5 = False
        self.in_abstract = False
        self.heading = ''
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'h5':
            if self.in_abstract:
                self.in_abstract = False
            self.in_h5 = True
            self.heading = ''

    def handle_endtag(self, tag):
        if tag.lower() == 'h5':
            self.in_h5 = False
            if self.heading.strip().lower() == 'abstract':
                self.in_abstract = True

    def handle_data(self, data):
        if self.in_h5:
            self.heading += data
        elif self.in_abstract:
            value = data.strip()
            if value:
                self.parts.append(value)

    def result(self):
        return ' '.join(self.parts).strip()


def _acl_id_from_text(text):
    text = text or ''
    match = _ACL_NEW_ID.search(text) or _ACL_OLD_ID.search(text)
    return match.group(1) if match else None


def _acl_metadata(browser, anthology_id, timeout, log):
    base = 'https://aclanthology.org/' + anthology_id
    xml_data = browser.open_novisit(base + '.xml', timeout=timeout).read()
    root = ET.fromstring(xml_data)
    mods = root.find(MODS_NS + 'mods')
    if mods is None:
        return None

    def first_text(path):
        node = mods.find(path, {'m': 'http://www.loc.gov/mods/v3'})
        return _clean_text(''.join(node.itertext())) if node is not None else ''

    title = first_text('m:titleInfo/m:title')
    authors = []
    for name in mods.findall('m:name', {'m': 'http://www.loc.gov/mods/v3'}):
        role = name.find('.//m:roleTerm', {'m': 'http://www.loc.gov/mods/v3'})
        if role is not None and (role.text or '').strip().lower() != 'author':
            continue
        given = ' '.join((x.text or '').strip() for x in name.findall('m:namePart[@type="given"]', {'m': 'http://www.loc.gov/mods/v3'}) if (x.text or '').strip())
        family = ' '.join((x.text or '').strip() for x in name.findall('m:namePart[@type="family"]', {'m': 'http://www.loc.gov/mods/v3'}) if (x.text or '').strip())
        full = _clean_text(given + ' ' + family)
        if not full:
            full = _clean_text(' '.join(x.text or '' for x in name.findall('m:namePart', {'m': 'http://www.loc.gov/mods/v3'})))
        if full:
            authors.append(full)

    date = first_text('m:originInfo/m:dateIssued')
    doi = ''
    for ident in mods.findall('m:identifier', {'m': 'http://www.loc.gov/mods/v3'}):
        if ident.attrib.get('type', '').lower() == 'doi':
            doi = _clean_text(ident.text)
            break
    publisher = first_text('m:relatedItem/m:originInfo/m:publisher')
    journal = first_text('m:relatedItem/m:titleInfo/m:title')
    page_start = first_text('m:part/m:extent[@unit="page"]/m:start')
    page_end = first_text('m:part/m:extent[@unit="page"]/m:end')

    abstract = ''
    try:
        html = browser.open_novisit(base + '/', timeout=timeout).read().decode('utf-8', 'replace')
        parser = _ACLAbstractParser()
        parser.feed(html)
        abstract = parser.result()
    except Exception as err:
        log('ACL Anthology: abstract indisponível (%s)' % err)

    if not title or not authors:
        return None
    return {
        'title': title, 'authors': authors, 'abstract': abstract,
        'date': date, 'doi': doi, 'publisher': publisher,
        'journal': journal, 'pages': (page_start + '-' + page_end).strip('-'),
        'id': anthology_id, 'url': base + '/'
    }


class ArxivMetadata(Source):
    name = 'Scientific Metadata for Calibre'
    description = 'Retrieves scientific publication metadata from arXiv and ACL Anthology.'
    author = 'Sérgio Inácio'
    version = (1, 1, 1)
    minimum_calibre_version = (6, 0, 0)
    supported_platforms = ['linux', 'windows', 'osx']
    capabilities = frozenset({'identify'})
    # Deliberately excludes tags: user-defined Calibre tags are collection labels
    # and must not be overwritten by arXiv subject categories.
    touched_fields = frozenset({'title', 'authors', 'comments', 'pubdate', 'identifiers', 'publisher', 'series', 'languages'})
    has_html_comments = False
    priority = 2

    def identify(self, log, result_queue, abort, title=None, authors=None,
                 identifiers=None, timeout=30):
        acl_id = _acl_id_from_text(title)
        arxiv_id = _extract_arxiv_id(title, identifiers)
        if not arxiv_id and not acl_id:
            return None
        if abort.is_set():
            return None

        url = ('https://export.arxiv.org/api/query?id_list=' + quote(arxiv_id, safe='/')) if arxiv_id else None
        try:
            if acl_id:
                log('ACL Anthology: a consultar %s' % acl_id)
                data = _acl_metadata(self.browser, acl_id, timeout, log)
                if not data:
                    log('ACL Anthology: não foram encontrados metadados válidos para %s' % acl_id)
                    return None
                if abort.is_set():
                    return None
                mi = Metadata(data['title'], data['authors'])
                mi.comments = data['abstract'] or None
                if data['date']:
                    try:
                        mi.pubdate = parse_date(data['date'][:10])
                    except Exception:
                        pass
                mi.identifiers = {'acl': data['id']}
                if data['doi']:
                    mi.identifiers['doi'] = data['doi']
                mi.url = data['url']
                if data['publisher']:
                    mi.publisher = data['publisher']
                if data['journal']:
                    mi.series = data['journal']
                mi.source_relevance = 0
                result_queue.put(mi)
                log('ACL Anthology: metadados encontrados — %s' % data['title'])
                return None
            log('arXiv: a consultar %s' % arxiv_id)
            global _LAST_API_REQUEST
            with _API_LOCK:
                wait = _API_MIN_INTERVAL - (time.monotonic() - _LAST_API_REQUEST)
                if wait > 0:
                    # Check cancellation periodically while waiting for the API slot.
                    deadline = time.monotonic() + wait
                    while time.monotonic() < deadline:
                        if abort.is_set():
                            return None
                        time.sleep(min(0.25, max(0.0, deadline - time.monotonic())))
                if abort.is_set():
                    return None
                _LAST_API_REQUEST = time.monotonic()
                response = self.browser.open_novisit(url, timeout=timeout)
                raw = response.read()
            data = _parse_entry(raw, arxiv_id)
            if not data:
                log('arXiv: não foram encontrados metadados válidos para %s' % arxiv_id)
                return None

            if abort.is_set():
                return None

            mi = Metadata(data['title'], data['authors'])
            mi.comments = data['abstract'] or None
            if data['published']:
                try:
                    mi.pubdate = parse_date(data['published'][:10])
                except Exception:
                    pass

            mi.identifiers = {'arxiv': data['arxiv_id']}
            if data['doi']:
                mi.identifiers['doi'] = data['doi']
            mi.url = 'https://arxiv.org/abs/' + data['arxiv_id']
            mi.source_relevance = 0

            # Intentionally do not set tags, publisher, series, rating or cover.
            # In particular, existing user collection tags remain untouched.
            result_queue.put(mi)
            log('arXiv: metadados encontrados — %s' % data['title'])
            return None
        except Exception as err:
            try:
                log.exception('Erro ao consultar a API do arXiv para %s' % arxiv_id)
            except Exception:
                log('Erro ao consultar a API do arXiv: %s' % err)
            return 'Erro ao consultar a API do arXiv: %s' % err

    def get_book_url(self, identifiers):
        arxiv_id = _extract_arxiv_id(None, identifiers)
        if arxiv_id:
            return ('arxiv', arxiv_id, 'https://arxiv.org/abs/' + arxiv_id)
        acl_id = _acl_id_from_text(' '.join(str(v) for v in (identifiers or {}).values()))
        if acl_id:
            return ('acl', acl_id, 'https://aclanthology.org/' + acl_id + '/')
        return None

    def id_from_url(self, url):
        if not url:
            return None
        match = re.search(r'arxiv\.org/(?:abs|pdf)/([^?#]+)', url, re.I)
        if match:
            candidate = match.group(1).removesuffix('.pdf')
            found = _NEW_ID.search(candidate) or _OLD_ID.search(candidate)
            if found:
                return ('arxiv', found.group(0))
        match = re.search(r'aclanthology\.org/([^/?#]+)', url, re.I)
        if match:
            acl_id = _acl_id_from_text(match.group(1))
            if acl_id:
                return ('acl', acl_id)
        return None
